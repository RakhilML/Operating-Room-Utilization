WinGLPK - GLPK for Windows
==========================

Copyright (C) 2009-2017 Heinrich Schuchardt <xypron.glpk@gmx.de>

WinGLPK provides Windows binaries for the GNU Linear Programmng Kit.

See the file COPYING for the GNU General Public Licence.

See the file INSTALL for compilation and installation instructions.
